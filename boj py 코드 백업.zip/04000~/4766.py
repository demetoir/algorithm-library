a=float(raw_input())
while 1:
    b=float(raw_input())
    if b==999:break
    print "%.2f"%(b-a)
    a=b