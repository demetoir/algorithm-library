for T in range(input()):
	s=raw_input()
	print s[0].upper()+s[1:]