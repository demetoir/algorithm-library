k,n,m=map(int,raw_input().split())
print max(0,k*n-m)