s=raw_input()
print len(s.split(","))