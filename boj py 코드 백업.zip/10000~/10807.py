n=input()
l=map(int,raw_input().split())
v=input()
print l.count(v)