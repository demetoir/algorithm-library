input()
l=map(int,raw_input().split())
print min(l),max(l)