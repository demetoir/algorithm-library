﻿for T in range(int(input())):
 a=0
 input()
 for i in range(int(input())):a+=int(input())
 if a%(i+1)==0:print("YES")
 else:print("NO")