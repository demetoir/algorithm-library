a=0
for i in range(int(input())+1):a+=3*(i+1)*i//2
print(a)