
n=int(raw_input(),2)
ans=str(oct(n))[1:].replace("L","")

print ans

