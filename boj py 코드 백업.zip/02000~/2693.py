﻿for i in range(int(input())):
    l=list(map(int,input().split()))
    l.sort()
    print(l[7])