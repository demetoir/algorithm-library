﻿l="DCBAE"
for _ in range(3):print(l[sum(list(map(int,input().split())))])