a=map(int,raw_input().split())
a.sort()
print a[0]*a[2]
