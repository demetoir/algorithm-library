﻿s=1
for i in range(int(input())):s+=int(input())-1
print(s)