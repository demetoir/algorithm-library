﻿a=str(int(input())*int(input())*int(input()))
for i in range(10):print(a.count(str(i)))