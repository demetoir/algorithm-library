﻿a=int(input());b=int(input())
for i in[a+b,a-b,a*b]:print(i)