﻿a=int(input());b=input()
for i in [0,1,2]:print(a*int(b[2-i]))
print(a*int(b))