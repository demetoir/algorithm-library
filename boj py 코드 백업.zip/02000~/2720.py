for T in range(input()):
	m=input()
	a=m//25
	m=m%25
	b=m//10
	m=m%10
	c=m//5
	m=m%5
	print a,b,c,m
