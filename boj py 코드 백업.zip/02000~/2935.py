a=input()
c=raw_input()
b=input()
if c=="+":print a+b
else:print a*b