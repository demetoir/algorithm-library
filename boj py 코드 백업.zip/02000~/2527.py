﻿def is_point(a,b):
    return 1 if len(set(a+b))==7 else 0
def is_line(a,b):

