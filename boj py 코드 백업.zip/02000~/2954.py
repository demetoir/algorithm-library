s=input()
for p in "aeiou":s=s.replace(p+"p"+p,p)
print(s)