﻿b=[]
for i in range(9):b.append(int(input()))
print(max(b))
print(b.index(max(b))+1)