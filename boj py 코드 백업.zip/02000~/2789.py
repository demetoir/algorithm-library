s="CAMBRIDGE"
ans=""
for i in input():
    if i not in s:ans+=i
print(ans)