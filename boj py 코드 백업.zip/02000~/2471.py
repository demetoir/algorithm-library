import math
print int(math.ceil((input()**0.5)))