﻿a=1;b=1;c=0
for i in range(int(input())):c=a+b;a=b%15746;b=c%15746
print(a)