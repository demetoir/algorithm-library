#N,K=map(int,input().split())
N=25
k=2
print(bin(25))