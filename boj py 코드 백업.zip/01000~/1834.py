n=input()
print n*(n+1)*(n-1)//2