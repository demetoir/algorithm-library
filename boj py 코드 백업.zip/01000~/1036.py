﻿print(ord("A"))
print(ord("9"))