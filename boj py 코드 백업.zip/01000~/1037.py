﻿input()
a=list(map(int,input().split()))
print(int(max(a)*min(a)))