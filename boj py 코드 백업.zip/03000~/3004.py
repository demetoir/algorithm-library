n=input()
a=n/2+1
print a*(a+n%2)
