import math
r=int(input())
print("%.6lf"%(r*r*math.pi))
print("%.6lf"%(r*r*2))