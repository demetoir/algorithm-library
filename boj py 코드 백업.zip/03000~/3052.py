﻿a={}
for i in range(10):a[int(input())%42]=1
print(len(a))