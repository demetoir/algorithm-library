ans=0
for i in range(5):
    ans+=input()
print ans